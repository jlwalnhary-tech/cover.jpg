<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>200 برومبت للمعلمين</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background-color: #f5f5f5; }
        h1 { color: #2c3e50; }
        p { font-size: 18px; color: #34495e; }
        a { display: inline-block; margin-top: 20px; padding: 15px 25px; background-color: #27ae60; color: white; text-decoration: none; font-size: 18px; border-radius: 5px; }
        a:hover { background-color: #2ecc71; }
        img { max-width: 300px; margin-top: 20px; }
    </style>
</head>
<body>
    <h1>200 برومبت احترافي للمعلمين</h1>
    <p>احصل على كتابك الرقمي الآن لتوليد محتوى تعليمي احترافي باستخدام الذكاء الاصطناعي!</p>
    <a href="https://gumroad.com/l/200prompts" target="_blank">اشترِ الآن بـ 5 دولار</a>
    <img src="cover.jpg" alt="غلاف الكتاب">
</body>
</html>
